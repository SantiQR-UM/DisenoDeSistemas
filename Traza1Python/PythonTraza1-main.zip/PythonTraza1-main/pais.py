from paprika import *


@data
class Pais:
    nombre: str