from typing import Optional
from paprika import *
from pais import Pais


@data
class Provincia:
    nombre: str
    pais : Pais