from typing import TypeVar, Generic, Dict, Optional, List, Any
import itertools
from threading import Lock

T = TypeVar("T")

class InMemoryRepository(Generic[T]):
    def __init__(self) -> None:
        self._data: Dict[int, T] = {}
        self._id_gen = itertools.count(1)  # IDs 1,2,3,...
        self._lock = Lock()

    # --------- Helpers ---------
    def _capitalize(self, s: str) -> str:
        return s[:1].upper() + s[1:] if s else s

    def _set_id(self, entity: T, value: int) -> None:
        """
        Intenta setear el ID como en Java:
        - Primero busca un método setId(value) o set_id(value)
        - Si no existe, intenta asignar el atributo entity.id = value
        """
        setter = getattr(entity, "setId", None) or getattr(entity, "set_id", None)
        if callable(setter):
            setter(value)
            return
        # Fallback: atributo "id"
        try:
            setattr(entity, "id", value)
        except Exception:
            pass  # Si no tiene forma de setear, no rompe (mismo comportamiento 'best effort')

    def _get_field_value(self, entity: T, field_name: str) -> Any:
        """
        Emula getCampo() de Java. Prueba en este orden:
        - get{Campo}()
        - get_{campo}()
        - atributo directo: entity.{campo}
        """
        cap = self._capitalize(field_name)

        # 1) getCampo()
        m = getattr(entity, f"get{cap}", None)
        if callable(m):
            return m()

        # 2) get_campo()
        m = getattr(entity, f"get_{field_name}", None)
        if callable(m):
            return m()

        # 3) atributo directo
        if hasattr(entity, field_name):
            return getattr(entity, field_name)

        return None

    # --------- API pública ---------
    def save(self, entity: T) -> T:
        with self._lock:
            new_id = next(self._id_gen)
            self._set_id(entity, new_id)
            self._data[new_id] = entity
        print(f"{type(entity).__name__}   id :{new_id}")
        return entity

    def find_by_id(self, id_: int) -> Optional[T]:
        return self._data.get(id_)

    def find_all(self) -> List[T]:
        return list(self._data.values())

    def generic_update(self, id_: int, updated_entity: T) -> Optional[T]:
        if id_ not in self._data:
            return None
        self._set_id(updated_entity, id_)
        self._data[id_] = updated_entity
        return updated_entity

    def generic_delete(self, id_: int) -> Optional[T]:
        return self._data.pop(id_, None)

    def generic_find_by_field(self, field_name: str, value: Any) -> List[T]:
        results: List[T] = []
        for entity in self._data.values():
            field_val = self._get_field_value(entity, field_name)
            if field_val is not None and field_val == value:
                results.append(entity)
        return results
