package tp2.ej5;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Plato {
    private String nombre;
}
