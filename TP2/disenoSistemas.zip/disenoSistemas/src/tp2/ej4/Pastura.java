package tp2.ej4;

import lombok.AllArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@SuperBuilder
@ToString(callSuper = true)

public class Pastura extends Cereal {

}
